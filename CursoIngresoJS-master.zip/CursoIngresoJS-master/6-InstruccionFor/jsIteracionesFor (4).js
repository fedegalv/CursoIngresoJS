function Mostrar()
{




}//FIN DE LA FUNCIÓN