function Mostrar()
{
//tomo la edad  


}//FIN DE LA FUNCIÓN